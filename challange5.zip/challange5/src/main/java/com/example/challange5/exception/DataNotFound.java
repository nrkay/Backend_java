package com.example.challange5.exception;

public class DataNotFound extends RuntimeException{
}
