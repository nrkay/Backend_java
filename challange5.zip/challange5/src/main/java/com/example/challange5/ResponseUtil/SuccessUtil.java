package com.example.challange5.ResponseUtil;

import com.example.challange5.model.Respon.ResponData;

public class SuccessUtil {

}
